public enum Szolofajta {
    Kékfrankos,
    Furmint,
    Leányka
}
